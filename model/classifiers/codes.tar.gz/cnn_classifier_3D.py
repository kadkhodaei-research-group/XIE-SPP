from keras.layers import Input, Dense, Conv2D, MaxPooling2D, UpSampling2D, BatchNormalization, Activation

from keras.models import Input, Model
from keras.layers import Conv3D, Conv2D, MaxPooling2D
from keras.layers import MaxPooling3D, UpSampling3D
from utility.util_tf import tf_shut_up
from keras import metrics, Model
from keras import regularizers
from keras import layers
from keras.models import Sequential
from utility.util_general import *

from keras.utils.vis_utils import plot_model


def build_model(n=128, verbose=False):
    """
    This function builds the convolutional autoencoder model
    """

    input_img = Input(shape=(n, n, n, 1))

    # encoder
    layer1 = (8, 8, 2)
    net = Conv3D(layer1[0], layer1[1], activation='relu', padding='same')(input_img)
    net = MaxPooling3D(layer1[2], padding='same')(net)

    layer2 = (16, 5, 2)
    net = Conv3D(layer2[0], layer2[1], activation='relu', padding='same')(net)
    net = MaxPooling3D(layer2[2], padding='same')(net)

    layer3 = (32, 3, 2)
    net = Conv3D(layer3[0], layer3[1], activation='relu', padding='same')(net)
    encoded = MaxPooling3D(layer3[2], padding='same', name='enc')(net)

    # decoder
    net = Conv3D(layer3[0], layer3[1], activation='relu', padding='same')(encoded)
    net = UpSampling3D(layer3[2])(net)

    net = Conv3D(layer2[0], layer2[1], activation='relu', padding='same')(net)
    net = UpSampling3D(layer2[2])(net)

    net = Conv3D(layer1[0], layer1[1], activation='relu', padding='same')(net)
    net = UpSampling3D(layer1[2])(net)

    decoded = Conv3D(1, layer1[1], activation='sigmoid', padding='same')(net)
    model = Model(input_img, decoded)
    # , metrics.categorical_accuracy
    tracked_metrics = [metrics.mae, metrics.mse, metrics.binary_crossentropy, metrics.mean_squared_logarithmic_error,
                       metrics.logcosh]
    # model.compile(optimizer='adam', loss='binary_crossentropy', metrics=met)
    model.compile(optimizer='adam', loss='mse', metrics=tracked_metrics)
    if verbose:
        print('Classifier built')
        model.summary()
        # plot_model(model, to_file='results/model_plot.png', show_shapes=True, show_layer_names=True)
        for i in model.get_config()['layers']:
            if 'kernel_size' in i['config']:
                print(i['config']['name'], '\t kernel size = ', i['config']['kernel_size'])
    if not model.layers[0].batch_input_shape == model.layers[-1].output_shape:
        raise ValueError('The input and output shape of the model is not the same')
    return model


def build_model_4(input_shape=(32, 32, 32, 1), loss='ali'):
    input_img = Input(shape=input_shape)
    x = Conv3D(64, (3, 3, 1), padding='same')(input_img)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = MaxPooling3D((2, 2, 1), padding='same')(x)
    x = Conv3D(32, (3, 3, 1), padding='same')(x)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = MaxPooling3D((2, 2, 1), padding='same')(x)
    x = Conv3D(16, (3, 3, 1), padding='same')(x)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    encoded = MaxPooling3D((2, 2, 1), padding='same')(x)

    x = Conv3D(16, (3, 3, 1), padding='same')(encoded)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = UpSampling3D((2, 2, 1))(x)
    x = Conv3D(32, (3, 3, 1), padding='same')(x)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = UpSampling3D((2, 2, 1))(x)
    x = Conv3D(64, (3, 3, 1), padding='same')(x)
    x = BatchNormalization()(x)
    x = Activation('relu')(x)
    x = UpSampling3D((2, 2, 1))(x)
    x = Conv3D(1, (3, 3, 1), padding='same')(x)
    x = BatchNormalization()(x)
    decoded = Activation('sigmoid')(x)

    model: Model = Model(input_img, decoded)
    tracked_metrics = [metrics.mae, metrics.mse, metrics.binary_crossentropy, metrics.mean_squared_logarithmic_error,
                       metrics.logcosh]

    model.compile(optimizer='adam', loss=loss, metrics=tracked_metrics)
    model.summary()
    return model


def model_5_cae(input_shape, loss='binary_crossentropy',
                optimizer='rmsprop'):  # CNN: https://www.kaggle.com/sarvajna/dogs-vs-cats-keras-solution/data
    print('MODEL 5')
    model = Sequential()

    model.add(layers.InputLayer(input_shape=input_shape))

    model.add(layers.Conv3D(32, (3, 3, 3), padding='same'))
    model.add(layers.Activation('relu'))
    model.add(layers.MaxPooling3D(pool_size=(2, 2, 2)))

    model.add(layers.Conv3D(32, (3, 3, 3), padding='same'))
    model.add(layers.Activation('relu'))
    model.add(layers.MaxPooling3D(pool_size=(2, 2, 2)))

    model.add(layers.Conv3D(64, (3, 3, 3), padding='same'))
    model.add(layers.Activation('relu'))
    model.add(layers.MaxPooling3D(pool_size=(2, 2, 2), name='encoded'))

    model.add(layers.Conv3D(64, (3, 3, 3), padding='same'))
    model.add(layers.Activation('relu'))
    model.add(layers.UpSampling3D((2, 2, 2)))

    model.add(layers.Conv3D(32, (3, 3, 3), padding='same'))
    model.add(layers.Activation('relu'))
    model.add(layers.UpSampling3D((2, 2, 2)))

    model.add(layers.Conv3D(32, (3, 3, 3), padding='same'))
    model.add(layers.Activation('relu'))
    model.add(layers.UpSampling3D((2, 2, 2)))

    model.add(layers.Conv3D(input_shape[-1], (3, 3, 3), padding='same'))
    model.add(layers.Activation('sigmoid'))

    model.compile(loss=loss,
                  optimizer=optimizer,
                  # metrics=['accuracy']
                  )
    model.summary()
    return model


def model_5_mod2_cae(input_shape, loss='binary_crossentropy',
                     optimizer='rmsprop'):  # CNN: https://www.kaggle.com/sarvajna/dogs-vs-cats-keras-solution/data
    print('MODEL 5 mod2')
    model = Sequential()

    model.add(layers.InputLayer(input_shape=input_shape))

    model.add(layers.Conv3D(32, (3, 3, 3), padding='same'))
    model.add(layers.Activation('relu'))
    model.add(layers.MaxPooling3D(pool_size=(2, 2, 2)))

    model.add(layers.Conv3D(32, (3, 3, 3), padding='same'))
    model.add(layers.Activation('relu'))
    model.add(layers.MaxPooling3D(pool_size=(2, 2, 2)))

    model.add(layers.Conv3D(64, (3, 3, 3), padding='same'))
    model.add(layers.Activation('relu'))
    model.add(layers.MaxPooling3D(pool_size=(2, 2, 2)))

    model.add(layers.Conv3D(128, (3, 3, 3), padding='same'))
    model.add(layers.Activation('relu'))
    model.add(layers.MaxPooling3D(pool_size=(2, 2, 2), name='encoded'))

    model.add(layers.Conv3D(128, (3, 3, 3), padding='same'))
    model.add(layers.Activation('relu'))
    model.add(layers.UpSampling3D((2, 2, 2)))

    model.add(layers.Conv3D(64, (3, 3, 3), padding='same'))
    model.add(layers.Activation('relu'))
    model.add(layers.UpSampling3D((2, 2, 2)))

    model.add(layers.Conv3D(32, (3, 3, 3), padding='same'))
    model.add(layers.Activation('relu'))
    model.add(layers.UpSampling3D((2, 2, 2)))

    model.add(layers.Conv3D(32, (3, 3, 3), padding='same'))
    model.add(layers.Activation('relu'))
    model.add(layers.UpSampling3D((2, 2, 2)))

    model.add(layers.Conv3D(input_shape[-1], (3, 3, 3), padding='same'))
    model.add(layers.Activation('sigmoid'))

    model.compile(loss=loss,
                  optimizer=optimizer,
                  metrics=['accuracy'])
    model.summary()
    return model


def model_5_mod3_cae(input_shape, loss='binary_crossentropy',
                     optimizer='rmsprop'):  # CNN: https://www.kaggle.com/sarvajna/dogs-vs-cats-keras-solution/data
    print('MODEL 5 mod3')
    print('The effect of bigger filter size')

    fs = 6
    print('filter size = ', fs)
    model = Sequential()

    model.add(layers.InputLayer(input_shape=input_shape))

    model.add(layers.Conv3D(32, (fs, fs, fs), padding='same'))
    model.add(layers.Activation('relu'))
    model.add(layers.MaxPooling3D(pool_size=(2, 2, 2)))

    model.add(layers.Conv3D(32, (fs, fs, fs), padding='same'))
    model.add(layers.Activation('relu'))
    model.add(layers.MaxPooling3D(pool_size=(2, 2, 2)))

    model.add(layers.Conv3D(64, (fs, fs, fs), padding='same'))
    model.add(layers.Activation('relu'))
    model.add(layers.MaxPooling3D(pool_size=(2, 2, 2), name='encoded'))

    model.add(layers.Conv3D(64, (fs, fs, fs), padding='same'))
    model.add(layers.Activation('relu'))
    model.add(layers.UpSampling3D((2, 2, 2)))

    model.add(layers.Conv3D(32, (fs, fs, fs), padding='same'))
    model.add(layers.Activation('relu'))
    model.add(layers.UpSampling3D((2, 2, 2)))

    model.add(layers.Conv3D(32, (fs, fs, fs), padding='same'))
    model.add(layers.Activation('relu'))
    model.add(layers.UpSampling3D((2, 2, 2)))

    model.add(layers.Conv3D(input_shape[-1], (fs, fs, fs), padding='same'))
    model.add(layers.Activation('sigmoid'))

    model.compile(loss=loss,
                  optimizer=optimizer,
                  metrics=['accuracy'])
    model.summary()
    return model


def model_5_mod4_cae(input_shape, loss='binary_crossentropy',
                     optimizer='rmsprop'):  # CNN: https://www.kaggle.com/sarvajna/dogs-vs-cats-keras-solution/data
    print('MODEL 5')
    model = Sequential()

    model.add(layers.InputLayer(input_shape=input_shape))

    model.add(layers.Conv3D(32, (3, 3, 3), padding='same', activity_regularizer=regularizers.l1(0.01)))
    model.add(layers.Activation('relu'))
    model.add(layers.MaxPooling3D(pool_size=(2, 2, 2)))

    model.add(layers.Conv3D(32, (3, 3, 3), padding='same', activity_regularizer=regularizers.l1(0.01)))
    model.add(layers.Activation('relu'))
    model.add(layers.MaxPooling3D(pool_size=(2, 2, 2)))

    model.add(layers.Conv3D(64, (3, 3, 3), padding='same', activity_regularizer=regularizers.l1(0.01)))
    model.add(layers.Activation('relu'))
    model.add(layers.MaxPooling3D(pool_size=(2, 2, 2), name='encoded'))

    model.add(layers.Conv3D(64, (3, 3, 3), padding='same', activity_regularizer=regularizers.l1(0.01)))
    model.add(layers.Activation('relu'))
    model.add(layers.UpSampling3D((2, 2, 2)))

    model.add(layers.Conv3D(32, (3, 3, 3), padding='same', activity_regularizer=regularizers.l1(0.01)))
    model.add(layers.Activation('relu'))
    model.add(layers.UpSampling3D((2, 2, 2)))

    model.add(layers.Conv3D(32, (3, 3, 3), padding='same', activity_regularizer=regularizers.l1(0.01)))
    model.add(layers.Activation('relu'))
    model.add(layers.UpSampling3D((2, 2, 2)))

    model.add(layers.Conv3D(input_shape[-1], (3, 3, 3), padding='same', activity_regularizer=regularizers.l1(0.01)))
    model.add(layers.Activation('sigmoid'))

    model.compile(loss=loss,
                  optimizer=optimizer,
                  metrics=['accuracy'])
    model.summary()
    return model


class CAE:
    def __init__(self,
                 input_shape,
                 channels=None,
                 kernel_size=(3, 3, 3),
                 activation=None,
                 pool_size=None,
                 loss='binary_crossentropy',
                 optimizer='rmsprop',
                 metrics=None,
                 verbose=True
                 ):
        if channels is None:
            channels = [32, 32, 64]
        if activation is None:
            activation = ['relu', 'sigmoid']
        if pool_size is None:
            pool_size = 2
        if isinstance(pool_size, int):
            pool_size = [pool_size] * len(channels)
        if isinstance(pool_size, list):
            pool_size = [(i, i, i) for i in pool_size]
        self.input_shape = input_shape
        self.channels = channels
        self.kernel_size = kernel_size
        self.activation = activation
        self.pool_size = pool_size
        self.loss = loss
        self.optimizer = optimizer
        self.metrics = metrics
        self.verbose = verbose

    def generate(self):
        if self.verbose:
            print('\nMODEL 5 adjustable params:')
            print('\n'.join([str(i) + ': ' + str(j) for i, j in self.__dict__.items()]) + '\n')

        channels = self.channels.copy()
        pool_size = self.pool_size.copy()

        mod = Sequential()
        mod.add(layers.InputLayer(input_shape=self.input_shape))

        for e in ['encoded', 'decoded']:
            if e == 'decoded':
                channels.reverse()
                channels.append(self.input_shape[-1])
                pool_size.reverse()
            for i in range(len(channels)):
                name = None
                activation = self.activation[0]
                if i == len(channels) - 1:
                    name = e
                    if e == 'decoded':
                        activation = self.activation[1]

                mod.add(layers.Conv3D(filters=channels[i], kernel_size=self.kernel_size, padding='same'))
                mod.add(layers.Activation(activation))
                if e == 'encoded':
                    mod.add(layers.MaxPooling3D(pool_size=pool_size[i], name=name))
                if e == 'decoded' and (not i == len(channels) - 1):
                    mod.add(layers.UpSampling3D(pool_size[i]))

        mod.compile(loss=self.loss,
                    optimizer=self.optimizer,
                    metrics=self.metrics
                    )
        if self.verbose > 1:
            mod.summary()
        return mod

    def generate_and_initialize_weights(self, weight_file):
        cae_1 = self.generate()
        if not exists(weight_file):
            raise FileNotFoundError('weight file was not found!')
        cae_1.load_weights(weight_file)
        return cae_1

    def generate_encoder(self, weigh_file):
        cae_1 = self.generate_and_initialize_weights(weigh_file)
        for i in range(len(cae_1.layers)):
            if ('encode' in cae_1.layers[-1].name) or ('pooling' in cae_1.layers[-1].name):
                break
            cae_1.pop()
        cae_1.add(layers.Flatten())
        return cae_1


if __name__ == "__main__":
    tf_shut_up()
    model = CAE(input_shape=(128, 128, 128, 3), pool_size=[4, 4, 2])
    cae = model.generate()
    # model_cae_adjustable((128, 128, 128, 3))

    # input_img = Input(shape=(28, 28, 1))  # adapt this if using `channels_first` image data format
    #
    # x = Conv2D(16, (3, 3), activation='relu', padding='same')(input_img)
    # x = MaxPooling2D((2, 2), padding='same')(x)
    # x = Conv2D(8, (3, 3), activation='relu', padding='same')(x)
    # x = MaxPooling2D((2, 2), padding='same')(x)
    # x = Conv2D(8, (3, 3), activation='relu', padding='same')(x)
    # encoded = MaxPooling2D((2, 2), padding='same')(x)
    #
    # # at this point the representation is (4, 4, 8) i.e. 128-dimensional
    #
    # x = Conv2D(8, (3, 3), activation='relu', padding='same')(encoded)
    # x = UpSampling2D((2, 2))(x)
    # x = Conv2D(8, (3, 3), activation='relu', padding='same')(x)
    # x = UpSampling2D((2, 2))(x)
    # x = Conv2D(16, (3, 3), activation='relu')(x)
    # x = UpSampling2D((2, 2))(x)
    # decoded = Conv2D(1, (3, 3), activation='sigmoid', padding='same')(x)
    #
    # autoencoder = Model(input_img, decoded)
    # autoencoder.summary()
    # autoencoder.compile(optimizer='adadelta', loss='binary_crossentropy')

    # Compiling the CNN
    # classifier.compile(optimizer='adam', loss = 'binary_crossentropy', metrics = ['accuracy'])
    # print('Classifier compiled ')
    # print(classifier)
    # return classifier

# def show_layers(model):
#     inp = model.input  # input placeholder
#     outputs = [layer.output for layer in model.layers]  # all layer outputs
#     functors = [K.function([inp, K.learning_phase()], [out]) for out in outputs]  # evaluation functions
#
#     # Testing
#     # input_shape = (32,32,32,1)
#     input_shape = model._feed_input_shapes[0][1:]
#     test = np.random.random(input_shape)[np.newaxis, ...]
#     layer_outs = [func([test, 1.]) for func in functors]
#     # print(layer_outs)
#
#     for i in range(len(model.layers)):
#         print('Layer: ', model.layers[i])
#         if i == 0:
#             sh = input_shape
#         else:
#             sh = layer_outs[i - 1][0].shape
#         print('Input Shape: ', sh, '\n')
#     print('Output shape: ', layer_outs[-1][0].shape)

# show_layers(build_model())

# autoencoder = build_model()
# autoencoder.summary()
# autoencoder.compile(optimizer='adam', loss='binary_crossentropy')
