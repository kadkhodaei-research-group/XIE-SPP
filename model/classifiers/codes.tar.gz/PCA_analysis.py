from utility.util_crystal import *
from sklearn.preprocessing import StandardScaler
from matplotlib import pyplot as plt
from sklearn.utils import shuffle
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
import pandas as pd
from sklearn.neural_network import MLPClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV
from sklearn import svm
from sklearn.metrics import accuracy_score, roc_auc_score
from feature_extraction import feature_extraction
from scipy.stats import pearsonr
from samplegenerator import SampleGenerator
from cnn_classifier_3D import CAE
from plots import plot_format
from imblearn.over_sampling import RandomOverSampler
import train_CAE_binary_clf
from data_preprocess import data_preparation

sns.set_style("darkgrid")


def manulay_do_pca(X_tr=None, y_tr=None, run_1=None, return_data=False, verbose=False):
    # mean_vec = np.mean(X_std, axis=0)
    # cov_mat = (X_std - mean_vec).T.dot((X_std - mean_vec)) / (X_std.shape[0]-1)
    # or simply np.cov(X_std.T)
    if X_tr is None:
        X_tr = X_train
        y_tr = y_train
        run_1 = run_1

    cov_mat = np.cov(X_tr[y_tr == 1].T)

    if verbose:
        print('Covariance matrix \n%s' % cov_mat)

    eig_vals, eig_vecs = np.linalg.eig(cov_mat)
    if verbose:
        print('Eigenvectors \n%s' % eig_vecs)
        print('\nEigenvalues \n%s' % eig_vals)

    # for ev in eig_vecs.T:
    #     np.testing.assert_array_almost_equal(1.0, np.linalg.norm(ev))
    # print('Everything ok!')

    # Make a list of (eigenvalue, eigenvector) tuples
    eig_pairs = [(np.abs(eig_vals[i]), eig_vecs[:, i]) for i in range(len(eig_vals))]

    # Sort the (eigenvalue, eigenvector) tuples from high to low
    eig_pairs.sort(key=lambda x: x[0], reverse=True)

    tot = sum(eig_vals)
    var_exp = [(i / tot) * 100 for i in sorted(eig_vals, reverse=True)]
    cum_var_exp = np.cumsum(var_exp)

    # save_var(locals(), run_1.results_path + 'cum_var_exp.pkl')

    if return_data:
        return cum_var_exp

    # with plt.style.context('seaborn-whitegrid'):
    #     plt.figure(figsize=(6, 4))
    #
    #     plt.bar(range(len(var_exp)), var_exp, alpha=0.5, align='center',
    #             label='individual explained variance')
    #     # plt.step(range(len(cum_var_exp)), cum_var_exp, where='mid',
    #     #          label='cumulative explained variance')
    #     plt.ylabel('Explained variance ratio')
    #     plt.xlabel('Principal components')
    #     plt.ylim(0, 1)
    #     plt.legend(loc='best')
    #     plt.tight_layout()
    #     plt.savefig(run.results_path + 'Explained Variance' + '.svg')
    #     plt.savefig(run.results_path + 'Explained Variance' + '.png', dpi=600)
    #     plt.show()
    #     plt.close('all')

    # with plt.style.context('seaborn-whitegrid'):
    plot_format(size=(88, 60))
    # plt.figure(figsize=(6, 4))
    plt.step(range(len(cum_var_exp)), cum_var_exp, where='mid',
             label='cumulative explained variance')
    plt.ylabel('Explained variance ratio')
    plt.xlabel('Principal components')
    plt.legend(loc='best')
    plt.tight_layout()
    plt.savefig(run_1.results_path + 'Cumulative Explained Variance' + '.svg')
    plt.savefig(run_1.results_path + 'Cumulative Explained Variance' + '.png', dpi=600)
    plt.show()
    # plt.close('all')

    # plt.plot(eig_vals)
    # plt.xlabel('n_components')
    # plt.ylabel('Eigenvalues')
    # plt.savefig(run.results_path + 'Eigenvalues' + '.svg')
    # plt.savefig(run.results_path + 'Eigenvalues' + '.png', dpi=600)
    # plt.show()
    #
    # plt.plot(eig_vals[:50])
    # plt.xlabel('n_components')
    # plt.ylabel('Eigenvalues')
    # plt.savefig(run.results_path + 'Eigenvalues_50' + '.svg')
    # plt.savefig(run.results_path + 'Eigenvalues_50' + '.png', dpi=600)
    # plt.show()

    df = pd.DataFrame({"Explained_variance": cum_var_exp,
                       'n_comp': range(len(cum_var_exp))})
    save_var(df, run_1.results_path + 'explained_variance.pkl')


def pca_vs_classification(X_tr=None, y_tr=None, run=None):
    if X_tr is None:
        X_tr, y_tr, _, _ = data_preparation()

    nn_clf = MLPClassifier(hidden_layer_sizes=(13, 13, 13), max_iter=500)
    rf_clf = RandomForestClassifier(max_depth=60, random_state=0, n_estimators=50)
    svm_clf = svm.SVC(gamma='auto', probability=True)
    clfs = [
        nn_clf,
        # rf_clf,
        # svm_clf,
    ]
    names = ['nn_clf', 'rf_clf', 'svm_clf']

    print('Apply standard scalar to features')
    if X_tr is None:
        X_tr = X_train
        y_tr = y_train
        run = run_1

    if run is None:
        run = RunSet()
    if (run is None) or (y_tr is None):
        raise ValueError('The function values are not initialized.')
    ss = StandardScaler()
    ss.fit(X_tr)
    X_digits = ss.transform(X_tr)
    y_digits = y_tr

    plt.figure(figsize=(4, 4))
    ax1 = plt.gca()
    grid_search = []
    for i in range(len(clfs)):
        pca = PCA()

        pipe = Pipeline(steps=[('pca', pca), (names[i], clfs[i])])

        # Parameters of pipelines can be set using ‘__’ separated parameter names:
        param_grid = {
            'pca__n_components': [1, 2, 3,
                                  4, 5, 10, 15,
                                  20, 30, 40, 50,
                                  64, 128, 256,
                                  512, 1024, 1500, 2000, 2500, 3000, 4096
                                  ],
        }
        print(f'Grid search operation for: {names[i]}', flush=True)
        search = GridSearchCV(pipe, param_grid, n_jobs=-1, verbose=2, cv=2, return_train_score=True)
        search.fit(X_digits, y_digits)
        print("Best parameter (CV score=%0.3f):" % search.best_score_)
        print(search.best_params_)

        # For each number of components, find the best classifier results
        results = pd.DataFrame(search.cv_results_)
        components_col = 'param_pca__n_components'
        best_clfs = results.groupby(components_col).apply(
            lambda g: g.nlargest(1, 'mean_test_score'))
        grid_search.append(best_clfs)
        save_var(grid_search, run.results_path + 'best_clfs_list.pkl')
        best_clfs.plot(x=components_col, y='mean_test_score', yerr='std_test_score',
                       label=names[i], ax=ax1)
    plt.legend(loc='best')
    ax1.set_ylabel('Classification accuracy (val)')
    ax1.set_xlabel('Number of PCA Components')

    plt.tight_layout()

    plt.savefig(run_1.results_path + 'Classification' + '.svg')
    plt.savefig(run_1.results_path + 'Classification' + '.png', dpi=600)
    plt.xlim(0, 500)
    plt.savefig(run_1.results_path + 'Classification_500' + '.svg')
    plt.savefig(run_1.results_path + 'Classification_500' + '.png', dpi=600)
    plt.xlim(0, 4200)
    plt.show()
    return locals()


def pca_vs_classification_2():
    nn_clf = MLPClassifier(hidden_layer_sizes=(13, 13, 13), max_iter=500)
    rf_clf = RandomForestClassifier(max_depth=20, random_state=0, n_estimators=50)
    svm_clf = svm.SVC(gamma='auto', probability=True)
    clfs = [
        svm_clf,
        nn_clf,
        # rf_clf
    ]
    names = ['svm_clf', 'nn_clf', 'rf_clf']

    print('Making PCAs')
    n_components = [1, 2, 3,
                    4, 5, 10, 15, 20,
                    # 40, 64, 128, 256,
                    # 512, 1024, 1500, 2048, 2500, 3000, 4000
                    ]
    pca_list = []

    print('Apply standard scalar to features')
    ss = StandardScaler()
    ss.fit(X_train)
    X_tr = ss.transform(X_train)
    X_te = ss.transform(X_test)

    pca_comp = PCA(n_components=None)
    print('Fitting')
    pca_comp.fit(X_train[y_train == 1])
    print('Transforming')
    X_tr_comp = pca_comp.transform(X_tr)
    X_te_comp = pca_comp.transform(X_te)
    # for i in range(len(n_components)):
    #     print(f'Making the PCA# {i}, n_components={n_components[i]}')
    #     pca_list.append(pca_comp)
    #     pca_list[i].fit(X_train[y_train == 1])

    # fig, (ax0, ax1) = plt.subplots(nrows=2, sharex=True, figsize=(6, 6))
    plt.figure(figsize=(6, 6))
    ax1 = plt.gca()
    for i in range(len(clfs)):
        acc = []
        for j in range(len(n_components)):
            print(f'Training classifier #{i} with PCA #{j}')
            clf = clfs[i]
            # X_tr = pca_list[j].transform(X_train)
            # X_te = pca_list[j].transform(X_test)
            X_tr = X_tr_comp[:, :n_components[j]]
            X_te = X_te_comp[:, :n_components[j]]
            clf.fit(X_tr, y_train)
            predY = clf.predict(X_te)
            acc.append(roc_auc_score(y_test, predY))

            print(f'AUC = {acc[-1]}')
        plt.plot(n_components, acc, label=names[i])

    plt.legend(loc='best')
    ax1.set_ylabel('Classification accuracy (val)')
    ax1.set_xlabel('n_components')

    # plt.xlim(-1, 70)

    plt.tight_layout()
    plt.savefig(run_1.results_path + 'Classification' + '.svg')
    plt.savefig(run_1.results_path + 'Classification' + '.png', dpi=600)
    plt.show()


def exp_var(data, eig_basis=None):
    cov_mat = np.cov(data.T)

    eig_vals, eig_vecs = np.linalg.eig(cov_mat)

    if eig_basis is None:
        eig_basis = eig_vals
    ind = np.argsort(eig_vals)[::-1]
    tot = sum(eig_basis)
    var_exp = [(eig_vals[i] / tot) * 100 for i in ind]
    # cum_var_exp = np.cumsum(var_exp)

    return var_exp, eig_basis


def explained_variance_comparision():
    print('Calc. cumulative explained variance')
    exp_var_train, basis = exp_var(X_train[y_train == 1])
    exp_var_test, _ = exp_var(X_test[y_test == 1], eig_basis=basis)
    exp_var_neg, _ = exp_var(X_train[~(y_train == 1)], eig_basis=basis)

    with plt.style.context('ggplot'):
        l = f'Training Positives, {len(X_train[y_train == 1])} ' \
            f'({len(X_train[y_train == 1]) / len(X_train[y_train == 1]) * 100:.1f}% Pos)'
        plt.step(range(len(exp_var_train)), np.cumsum(exp_var_train), where='mid',
                 label=l)
        l = f'Test Positives, {len(X_test[y_test == 1])} ' \
            f'({len(X_test[y_test == 1]) / len(X_test[y_test == 1]) * 100:.1f}% Pos)'
        plt.step(range(len(exp_var_test)), np.cumsum(exp_var_test), where='mid',
                 label=l)
        l = f'Training Negatives, {len(X_train[y_train == -1])} ' \
            f'({0 * 100:.1f}% Pos)'
        plt.step(range(len(exp_var_neg)), np.cumsum(exp_var_neg), where='mid',
                 label=l)
        plt.title('Cumulative Explained Variance')
        plt.ylabel('Explained variance ratio')
        plt.xlabel('Principal components')
        plt.legend(loc='best')
        plt.tight_layout()
        plt.savefig(run_1.results_path + 'EVR_Comparision' + '.svg')
        plt.savefig(run_1.results_path + 'EVR_Comparision' + '.png', dpi=600)
        plt.show()


def read_data(path):
    run_1 = RunSet(ini_from_path=path, params={'skip_error': True})

    print('Loading features')
    pos_train = load_var(run_1.last_run + 'pos_train_features.pkl.npz', uncompress=True)
    pos_train = pos_train[:len(pos_train) // 1]
    pos_test = load_var(run_1.last_run + 'pos_test_features.pkl.npz', uncompress=True)
    pos_test = pos_train[:len(pos_test) // 1]
    neg_x = load_var(run_1.last_run + 'neg_features.pkl.npz', uncompress=True)

    print('Calculations...')
    X_train_std = StandardScaler().fit_transform(pos_train)

    print('Splitting to train and test')
    neg_train, neg_test = train_test_split(neg_x, test_size=0.3, random_state=run_1.params['random_seed'])

    X_train = np.concatenate((pos_train, neg_train), axis=0)
    y_train = np.concatenate(([1] * len(pos_train), [-1] * len(neg_train)), axis=0)
    X_train, y_train = shuffle(X_train, y_train, random_state=run_1.params['random_seed'])

    X_test = np.concatenate((pos_test, neg_test), axis=0)
    y_test = np.concatenate(([1] * len(pos_test), [-1] * len(neg_test)), axis=0)
    X_test, y_test = shuffle(X_test, y_test, random_state=run_1.params['random_seed'])

    N = 1
    X_train = X_train[:len(X_train) // N]
    y_train = y_train[:len(y_train) // N]

    # N = 9
    X_test = X_test[:len(X_test) // N]
    y_test = y_test[:len(y_test) // N]

    print(f'Train: {len(X_train)} ({len(X_train[y_train == 1]) / len(X_train) * 100:.1f}% Pos)')
    print(f'Test: {len(X_test)} ({len(X_test[y_test == 1]) / len(X_test) * 100:.1f}% Pos)')

    manulay_do_pca()

    print('Apply standard scalar to features')
    ss = StandardScaler()
    ss.fit(X_train)
    X_train = ss.transform(X_train)
    X_test = ss.transform(X_test)


import math


def average(x):
    assert len(x) > 0
    return float(sum(x)) / len(x)


def pearson_def(x, y):
    assert len(x) == len(y)
    n = len(x)
    assert n > 0
    avg_x = average(x)
    avg_y = average(y)
    diff_prod = 0
    x_diff_2 = 0
    y_diff_2 = 0
    for idx in range(n):
        x_diff = x[idx] - avg_x
        y_diff = y[idx] - avg_y
        diff_prod += x_diff * y_diff
        x_diff_2 += x_diff * x_diff
        y_diff_2 += y_diff * y_diff

    return float(diff_prod / math.sqrt(x_diff_2 * y_diff_2))


def dataset_correlation_after_pca_based_on_1set():
    run_1 = RunSet(ini_from_path='results/run_041/', params={'skip_error': True})
    run_2 = RunSet(ini_from_path='/home/ali/Desktop/run_045/', params={'skip_error': True, 'run_id': run_1.run_id})

    pos_test_1 = load_var(run_1.last_run + 'pos_test_features.pkl.npz', uncompress=True)[:800]
    pos_test_2 = load_var(run_2.last_run + 'pos_test_2.pkl.npz', uncompress=True)[:800]

    ss1 = StandardScaler()
    ss1.fit(pos_test_1)
    pos_test_1 = ss1.transform(pos_test_1)
    pos_test_2 = ss1.transform(pos_test_2)

    pca1 = PCA(n_components=800, whiten=True)
    pca1.fit(pos_test_1)
    pos_test_1 = pca1.transform(pos_test_1)
    pos_test_2 = pca1.transform(pos_test_2)

    x1 = data1 = pos_test_1.astype('float')
    x2 = data2 = pos_test_2.astype('float')

    pearson_list = []
    for f in range(x1.shape[1]):
        pearson_list.append(pearson_def(x1[:, f], x2[:, f]))
    pearson_list = np.array(pearson_list)

    sns.set_style("darkgrid")
    f, ax = plt.subplots()
    ax2 = ax.twinx()
    sns.set_style("darkgrid")
    sns.distplot(pearson_list[pearson_list >= 0.5], kde=False, ax=ax, color='darkgreen', bins=10,
                 label='Notable Correlation')
    sns.distplot(pearson_list[pearson_list < 0.5], kde=False, ax=ax2, color='darkred', bins=10,
                 label='Less Correlation')
    lines2, labels2 = ax2.get_legend_handles_labels()
    lines, labels = ax.get_legend_handles_labels()
    ax.legend(lines + lines2, labels + labels2, loc='upper center')
    ax.set_ylabel('# of features with Notable Correlation')
    ax2.set_ylabel('# of features with Less Correlation')
    ax.set_xlabel('Pearson Correlation')
    plt.savefig(run_1.results_path + f'corr_dist.png')
    plt.show()

    for i in range(2):
        if i == 0:
            samples = random.sample(list(np.argwhere(pearson_list > 0.5)), 4)
            color = 'darkgreen'
        if i == 1:
            samples = random.sample(list(np.argwhere(pearson_list < 0.5)), 5)
            color = 'darkred'
        for j in samples:
            j = int(j)
            sns.set_style("darkgrid")
            ax = sns.scatterplot(x1[:, j], x2[:, j], color=color)
            ax.set_xlabel('Features from CAE 1')
            ax.set_ylabel('Features from CAE 2')
            plt.title(f'Feature number {j}\nPearson Correlation = {pearson_list[j]}')
            # plt.savefig(run_1.results_path + f'corr_{i}_{j}.png')
            plt.show()

    print('End df')


def dataset_correlation_after_pca():
    run_1 = RunSet(ini_from_path='results/run_041/', params={'skip_error': True})
    run_2 = RunSet(ini_from_path='/home/ali/Desktop/run_045/', params={'skip_error': True, 'run_id': run_1.run_id})

    pos_test_1 = load_var(run_1.last_run + 'pos_test_features.pkl.npz', uncompress=True)[:800]
    pos_test_2 = load_var(run_2.last_run + 'pos_test_2.pkl.npz', uncompress=True)[:800]

    ss1 = StandardScaler()
    ss1.fit(pos_test_1)
    pos_test_1 = ss1.transform(pos_test_1)
    ss2 = StandardScaler()
    ss2.fit(pos_test_2)
    pos_test_2 = ss2.transform(pos_test_2)

    pca1 = PCA(n_components=800, whiten=True)
    pos_test_1 = pca1.fit_transform(pos_test_1)
    pca2 = PCA(n_components=800, whiten=True)
    pos_test_2 = pca2.fit_transform(pos_test_2)

    x1 = data1 = pos_test_1.astype('float')
    x2 = data2 = pos_test_2.astype('float')

    pearson_list = []
    for f in range(x1.shape[1]):
        pearson_list.append(pearson_def(x1[:, f], x2[:, f]))
    pearson_list = np.array(pearson_list)

    sns.set_style("darkgrid")
    f, ax = plt.subplots()
    ax2 = ax.twinx()
    sns.set_style("darkgrid")
    sns.distplot(pearson_list[pearson_list >= 0.5], kde=False, ax=ax, color='darkgreen', bins=10,
                 label='Notable Correlation')
    sns.distplot(pearson_list[pearson_list < 0.5], kde=False, ax=ax2, color='darkred', bins=10,
                 label='Less Correlation')
    lines2, labels2 = ax2.get_legend_handles_labels()
    lines, labels = ax.get_legend_handles_labels()
    ax.legend(lines + lines2, labels + labels2, loc='upper center')
    ax.set_ylabel('# of features with Notable Correlation')
    ax2.set_ylabel('# of features with Less Correlation')
    ax.set_xlabel('Pearson Correlation')
    plt.savefig(run_1.results_path + f'corr_dist.png')
    plt.show()

    for i in range(2):
        if i == 0:
            samples = random.sample(list(np.argwhere(pearson_list > 0.5)), 5)
            color = 'darkgreen'
        if i == 1:
            samples = random.sample(list(np.argwhere(pearson_list < 0.5)), 5)
            color = 'darkred'
        for j in samples:
            j = int(j)
            sns.set_style("darkgrid")
            ax = sns.scatterplot(x1[:, j], x2[:, j], color=color)
            ax.set_xlabel('Features from CAE 1')
            ax.set_ylabel('Features from CAE 2')
            plt.title(f'Feature number {j}\nPearson Correlation = {pearson_list[j]}')
            plt.savefig(run_1.results_path + f'corr_{i}_{j}.png')
            plt.show()

    print('End df')


def dataset_correlation_before_pca():
    # run_1 = RunSet(ini_from_path='results/CAE/comb_41_43/', params={'skip_error': True})
    run_1 = RunSet(ini_from_path='results/CAE/run_041/', params={'skip_error': True})
    # run_2 = RunSet(ini_from_path='results/CAE/run_045/', params={'skip_error': True, 'run_id': run_1.run_id})

    # pos_test_1 = load_var(run_1.last_run + 'pos_test_corr.pkl.npz', uncompress=True)
    # pos_test_2 = load_var(run_2.last_run + 'pos_test_corr.pkl.npz', uncompress=True)
    pos_test_1 = load_var('results/CAE/comb_41_43/' + 'pos_test_corr.pkl.npz', uncompress=True)
    pos_test_2 = load_var('results/CAE/run_045/' + 'pos_test_corr.pkl.npz', uncompress=True)

    x1 = data1 = pos_test_1.astype('float')
    x2 = data2 = pos_test_2.astype('float')
    #
    # plt.scatter(x1[:,1], x2[:,1])
    # plt.show()

    pearson_list = []
    for f in range(x1.shape[1]):
        pearson_list.append(pearson_def(x1[:, f], x2[:, f]))
        if np.isnan(pearson_list[-1]):
            c = np.count_nonzero(x1[:, f] == x2[:, f]) / x1.shape[0] * 100
            # print(f'f{f}: {c}')
            if c > 90:
                pearson_list[-1] = 1
            else:
                pearson_list[-1] = 0
    pearson_list = np.array(pearson_list)

    # # Heat map
    # # Set up the matplotlib figure
    # # fig_size = (85, 75)
    # # f, ax = plt.subplots(figsize=(fig_size[0] / 100 * 3.93701, fig_size[1] / 100 * 3.93701))
    # f, ax, fs = plot_format((95, 95))
    # # Generate a custom diverging colormap
    # cmap = sns.diverging_palette(10, 150, as_cmap=True)
    # # Draw the heatmap with the mask and correct aspect ratio
    # corr = pearson_list.reshape((int(len(pearson_list) ** 0.5), int(len(pearson_list) ** 0.5)))
    # sns.heatmap(corr,
    #             # mask=mask,
    #             cmap=cmap, vmax=1, vmin=-1, center=0,
    #             square=True,
    #             linewidths=0.2,
    #             cbar_kws={"shrink": .8})
    # plt.title(f'Correlations of two CAEs\n'
    #           f'{run_1.last_run} & {run_2.last_run}\n'
    #           f'Avg. Correlation: {np.average(pearson_list):.4f}\n'
    #           f'Corr above 0.8: {np.count_nonzero(pearson_list>0.8)}')
    # plt.axis('off')
    # plt.show()

    sns.set_style("darkgrid")
    f, ax = plt.subplots()
    ax2 = ax.twinx()
    sns.set_style("darkgrid")
    sns.distplot(pearson_list[pearson_list >= 0.5], kde=False, ax=ax, color='darkgreen', bins=10,
                 label='Notable Correlation')
    sns.distplot(pearson_list[pearson_list < 0.5], kde=False, ax=ax2, color='darkred', bins=10,
                 label='Less Correlation')
    lines2, labels2 = ax2.get_legend_handles_labels()
    lines, labels = ax.get_legend_handles_labels()
    ax.legend(lines + lines2, labels + labels2, loc='upper center')
    ax.set_ylabel('# of features with Notable Correlation')
    ax2.set_ylabel('# of features with Less Correlation')
    ax.set_xlabel('Pearson Correlation')
    plt.savefig(run_1.results_path + f'corr_dist.png')
    plt.show()

    # for i in range(2):
    #     if i == 0:
    #         samples = random.sample(list(np.argwhere(pearson_list > 0.5)), 3)
    #         samples = [381, 298, 2889]
    #         color = 'darkgreen'
    #     if i == 1:
    #         samples = list(np.argwhere(pearson_list < 0.5))
    #         color = 'darkred'
    #     for j in samples:
    #         j = int(j)
    #         sns.set_style("darkgrid")
    #         ax = sns.scatterplot(x1[:, j], x2[:, j], color=color)
    #         ax.set_xlabel('Features from CAE 1')
    #         ax.set_ylabel('Features from CAE 2')
    #         plt.title(f'Feature number {j}\nPearson Correlation = {pearson_list[j]}')
    #         plt.savefig(run_1.results_path + f'corr_{i}_{j}.png')
    #         plt.show()

    print('End df')


def dataset_correlation_preparation(run_1: RunSet):
    #  https://machinelearningmastery.com/how-to-use-correlation-to-understand-the-relationship-between-variables/
    files = list_all_files(run_1.chunks_path, pattern='[0-9]*/[0-9.]*.npz')
    random.Random(20).shuffle(files)
    files = files[:92]
    gen = SampleGenerator(filename=files,
                          pad_len=run_1.pad_len,
                          n_bin=run_1.n_bins,
                          verbose=0,
                          sub_sec=run_1.batch_sub_sec,
                          channels=run_1.params['channels'],
                          name='generator'
                          )
    cae = CAE(input_shape=run_1.input_shape, pool_size=[4, 4, 2], optimizer='adam')
    cae_1 = cae.generate()
    cae_1.load_weights(run_1.last_run + 'weights_1.h5')
    pos_test_1 = feature_extraction(generator=gen, run=run_1, auto_encoder=cae_1)
    save_var(pos_test_1, run_1.last_run + 'pos_test_corr.pkl', compress_np=True)
    print("Correlation features extracted")


def within_dataset_correlation_heat_map_before_pca():
    run_1 = RunSet(ini_from_path='results/CAE/run_041/', params={'skip_error': True})
    x1 = load_var(run_1.last_run + 'pos_test_corr.pkl.npz', uncompress=True)

    cov_mat = np.cov(x1.T)

    print('Covariance matrix \n%s' % cov_mat)

    # eig_vals, eig_vecs = np.linalg.eig(cov_mat)

    corr = np.zeros((int(x1.shape[1]), int(x1.shape[1])))

    N = 20
    # for i in range(corr.shape[0]):
    for i in range(N):
        print(i)
        for j in range(0, i):
            corr[i, j] = pearson_def(x1[:, i], x1[:, j])
    save_var(corr, 'tmp/corr.pkl')
    # corr = cov_mat
    mask = np.triu(np.ones_like(corr, dtype=np.bool))

    f, ax, fs = plot_format((95 * 10, 85 * 10))
    # Generate a custom diverging colormap
    cmap = sns.diverging_palette(10, 150, as_cmap=True)
    # Draw the heatmap with the mask and correct aspect ratio
    sns.heatmap(corr[:N, :N],
                mask=mask[:N, :N],
                cmap=cmap, center=0,
                square=True,
                linewidths=0.2,
                cbar_kws={"shrink": .8})
    # plt.axis('off')
    plt.show()
    print('End fn')


def within_dataset_correlation_heat_map_after_pca():
    run_1 = RunSet(ini_from_path='results/CAE/run_041/', params={'skip_error': True})
    x1 = load_var(run_1.last_run + 'pos_test_corr.pkl.npz', uncompress=True)

    ss1 = StandardScaler()
    ss1.fit(x1)
    pos_test_1 = ss1.transform(x1)

    N = 30

    pca1 = PCA(n_components=N, whiten=True)
    pos_test_1 = pca1.fit_transform(pos_test_1)
    x1 = pos_test_1

    cov_mat = np.cov(x1.T)

    print('Covariance matrix \n%s' % cov_mat)

    # eig_vals, eig_vecs = np.linalg.eig(cov_mat)

    # corr = np.zeros((int(x1.shape[1]), int(x1.shape[1])))
    # for i in range(corr.shape[0]):
    #     print(i)
    #     for j in range(0, i):
    #         corr[i, j] = pearson_def(x1[:, i], x1[:, j])
    # save_var(corr, 'tmp/corr.pkl')
    corr = cov_mat
    mask = np.triu(np.ones_like(corr, dtype=np.bool))

    f, ax, fs = plot_format((95 * 10, 85 * 10))
    # Generate a custom diverging colormap
    cmap = sns.diverging_palette(10, 150, as_cmap=True)
    # Draw the heatmap with the mask and correct aspect ratio
    sns.heatmap(corr,
                mask=mask,
                cmap=cmap, center=0,
                square=True,
                linewidths=0.2,
                cbar_kws={"shrink": .8})
    # plt.axis('off')
    plt.show()
    print('End fn')


def X_y_preparation(filepath):
    global X_train, y_train, X_test, y_test, run_1
    run = RunSet(ini_from_path=filepath, params={'skip_error': True})

    zip_file = '.npz'
    if not exists(run.last_run + 'pos_train_features.pkl.npz'):
        zip_file = ''
    pos_train = load_var(run.last_run + 'pos_train_features.pkl' + zip_file, uncompress=True)
    pos_test = load_var(run.last_run + 'pos_test_features.pkl' + zip_file, uncompress=True)
    neg_x = load_var(run.last_run + 'neg_features.pkl' + zip_file, uncompress=True)

    neg_train, neg_test = train_test_split(neg_x, test_size=0.3, random_state=run.params['random_seed'])

    X_train = np.concatenate((pos_train, neg_train), axis=0)
    y_train = np.concatenate(([1] * len(pos_train), [-1] * len(neg_train)), axis=0)
    X_train, y_train = shuffle(X_train, y_train, random_state=run.params['random_seed'])

    X_test = np.concatenate((pos_test, neg_test), axis=0)
    y_test = np.concatenate(([1] * len(pos_test), [-1] * len(neg_test)), axis=0)
    X_test, y_test = shuffle(X_test, y_test, random_state=run.params['random_seed'])

    meta_data = []
    over_sampling = True
    if over_sampling:
        print('Over Sampling ... ')
        ros = RandomOverSampler(random_state=0)
        X_train, y_train = ros.fit_resample(X_train, y_train)
        X_test, y_test = ros.fit_resample(X_test, y_test)

        meta_data += ['\n']
        meta_data += ["Stats after over sampling"]
        print(meta_data[-1])
        meta_data += ['Total train Samples = {} \t '
                      'Pos_percent = {:.1f}%'.format(len(y_train),
                                                     np.count_nonzero(y_train == 1) / len(y_train) * 100)]
        print(meta_data[-1])
        meta_data += ['Total test Samples  = {} \t '
                      'Pos_percent = {:.1f}%'.format(len(y_test), np.count_nonzero(y_test == 1) / len(y_test) * 100)]
        print(meta_data[-1])


def pca_vs_classification_3():
    # cae_num = [
    #     43, 38, 39, 40,
    # ]

    common_batches = [9, 8]
    cae_number = get_arg_terminal('cae_n', default=43)
    path = f'{data_path}cod/results/CAE/run_{cae_number:03d}/'
    results_path = f'{data_path}cod/results/CAE/Classification_Comp/run_{cae_number:03d}/'
    print(f'Extracting common features for: {cae_number}', flush=True)

    print('Loading train set')
    data = data_preparation(over_sampling=True, standard_scaler=False, random_state=1,
                            apply_pca=False, pca_n_comp=4048, split_data_frac=1.,
                            pos_frac=1.0, make_dev_data=False, path=path, use_all_data=False,
                            )
    X_train, y_train, X_test, y_test = data
    X_common = load_var(path + f'features/batch_pos_{common_batches[0]:02d}.pkl.npz', uncompress=True)

    if len(X_common) > np.count_nonzero(y_test < 0):
        X_common = X_common[:np.count_nonzero(y_test < 0)]
    y_test = np.concatenate(([1] * len(X_common), [-1] * np.count_nonzero(y_test < 0)), axis=0)
    X_test = np.concatenate((X_common, X_test[y_test < 0]), axis=0)
    X_test, y_test = shuffle(X_test, y_test, random_state=0)

    n_features = [
        2, 4, 8,
        # 16,
        # 32, 50, 64, 128, 256,
        # 512, 1024,
    ]
    clf_labels = [
        'Random Forest',
        'Neural Network',
        # 'SVM',
    ]
    clfs = []
    comp_label = 'PCA components'
    cv = get_arg_terminal('cv', default=1)
    tasks = max(get_arg_terminal('tasks', default=1), 1)
    cpu_per_task = max(1, tot_cpu // tasks)
    print(f'Tot. CPU cores: {tot_cpu}\nTot. tasks: {tasks}\nCPU cores per task: {cpu_per_task}')
    clf_dic = {'Neural Network': MLPClassifier(hidden_layer_sizes=(13, 13, 13), max_iter=500, random_state=0),
               'Random Forest': RandomForestClassifier(max_depth=60, random_state=0, n_estimators=50,
                                                       n_jobs=cpu_per_task),
               'SVM': svm.SVC(gamma='auto', probability=True),
               }
    do_grid_search = True
    if do_grid_search:
        for k in clf_labels:
            for c in n_features:
                pca_i = PCA(n_components=int(c))

                clfs.append({
                    'name': k,
                    'comp_val': c,
                    'comp_name': comp_label,
                    'cv': cv,
                    'clf': Pipeline(steps=[
                        ('ss', StandardScaler()),
                        ('pca', pca_i),
                        ('clf', clf_dic[k]),
                    ]),
                    'xt': X_train.copy(),
                    'yt': y_train.copy(),
                    'train_score': True,
                })

        from joblib import Parallel, delayed
        from train_CAE_binary_clf import fit_classifiers, clf_score_p
        clfs = Parallel(n_jobs=tasks)(delayed(fit_classifiers)(c) for c in clfs)
        for r in clfs:
            r.pop('xt')
            r.pop('yt')
            # r['data_set'] = {'X_test': 'test'}
            # r['X_test'] = X_test.copy()
            # r['y_test'] = y_test.copy()

        save_var(clfs, f'{results_path}/clfs.pkl')

        print('Calc. scores', flush=True)
        for r in clfs:
            r['data_set'] = {'X_test': 'test', 'X_train': 'train'}
            r['X_test'] = X_test.copy()
            r['y_test'] = y_test.copy()

            r['xt'] = X_train.copy()
            r['yt'] = y_train.copy()

        results = Parallel(n_jobs=tasks)(delayed(clf_score_p)(c) for c in clfs)
        for r in results:
            r.pop('X_test')
            r.pop('y_test')
            r.pop('clf')
        results = pd.DataFrame(results)

        save_var(results, f'{results_path}results_pca_c.pkl')
        results.to_csv(f'{results_path}results_pca_c.csv')

    print('Evaluating predictions on the pca comp =1000\nStandard Scaler:')
    ss = StandardScaler()
    ss.fit(X_train)
    X_train = ss.transform(X_train)
    X_test = ss.transform(X_test)

    pca_n_comp = 1000
    print(f'Effective PCA components: {pca_n_comp:,}')
    pca = PCA(n_components=pca_n_comp, whiten=True, random_state=0)

    pca = pca.fit(X_train)
    print('Explained variance percentage = %0.2f' % sum(pca.explained_variance_ratio_))
    X_train = pca.transform(X_train)
    X_test = pca.transform(X_test)

    svm_clf = svm.SVC(gamma='auto', probability=True)
    nn_clf = MLPClassifier(hidden_layer_sizes=(13, 13, 13), max_iter=500, random_state=0)
    rf_clf = RandomForestClassifier(max_depth=60, random_state=0, n_estimators=50,
                                    n_jobs=get_arg_terminal('cpu', default=4))
    predictions = {}
    clf_list = [
        rf_clf,
        nn_clf,
        # svm_clf,
    ]
    classifiers = {}
    for c in clf_list:
        print('-' * 50)
        print(c)
        print('Classifier name: ', re.sub(r"(\w)([A-Z])", r"\1 \2", str(c)[:str(c).find('(')]), flush=True)
        t1 = datetime.now()
        if not str(c)[:str(c).find('(')] in classifiers.keys():
            c.fit(X_train, y_train)
        else:
            c = classifiers[str(c)[:str(c).find('(')]]

        predY_prob = c.predict_proba(X_test)[:, 1]
        predY = np.sign(np.sign(predY_prob - 0.5) - .5)
        dt = datetime.now() - t1
        print('Fitting and predicting time: {}'.format(str(dt).split('.')[0]))
        print('accuracy = {:.2f}%'.format(100 * accuracy_score(y_test, predY)))

        classifiers.update({str(c)[:str(c).find('(')]: c})
        predictions.update({str(c)[:str(c).find('(')]: predY_prob})
    labels = y_test
    save_var({'predictions': predictions, 'labels': labels}, f'{results_path}predictions.pkl')

    globals().update(locals())


if __name__ == '__main__':
    t0 = datetime.now()
    X_train, y_train, X_test, y_test = None, None, None, None
    run_1 = None

    load_X_y = False
    if load_X_y:
        X_y_preparation(get_arg_terminal('run_from', default='results/CAE/run_043/'))
        # X_y_preparation('results/CAE/ABC10/run_001/')
        # X_y_preparation('results/CAE/run_041/')
        # X_y_preparation('results/CAE/run_045/')
        # X_y_preparation('results/CAE/run_043/')

    # manulay_do_pca()

    # r1 = RunSet(ini_from_path='results/CAE/run_041/', params={'skip_error': True})
    # r2 = RunSet(ini_from_path='results/CAE/run_043/', params={'skip_error': True})
    # r3 = RunSet(ini_from_path='results/CAE/run_045/', params={'skip_error': True})

    # adapted https://sebastianraschka.com/Articles/2015_pca_in_3_steps.html
    # for r in [r1, r2, r3]:
    #     print('Dataset preparation')
    #     dataset_correlation_preparation(r)

    # dataset_correlation_before_pca()
    # dataset_correlation_after_pca()
    # dataset_correlation_after_pca_based_on_1set()
    # within_dataset_correlation_heat_map_before_pca()
    # within_dataset_correlation_heat_map_after_pca()

    # pca_ana_1 = pca_vs_classification()
    # pca_vs_classification_2()
    pca_vs_classification_3()

    # save_var(locals(), run.results_path + 'PCA_analysis-session.pkl')
    t1 = datetime.now()
    print(f'Calculation time: {t1 - t0}')
    print('The End')
