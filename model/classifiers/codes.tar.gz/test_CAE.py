from cnn_classifier_3D import *
from sklearn.model_selection import train_test_split
from utility.util_tf import *
from utility.util_crystal import *
from keras.callbacks import ModelCheckpoint  # , History
from feature_extraction import feature_extraction


from keras.utils import Sequence
from utility.util_crystal import *
import utility.util_crystal as util
import warnings


# import numpy as np
from cod_tools import channel_generator


class SampleGenerator(Sequence):
    """
    This generate samples for feeding keras.fit_generator.
    It gets an idx and it decides the which batch to be passed based on the initialized file names.

    -Ali Davari
    """

    def __init__(self, filename, labels='', batch_size=3, tot_batches=None, directory='', verbose=0, saved_chunks=True,
                 pad_len=70,
                 n_bin=128,
                 test_run=False, sub_sec=1, channels=None, name='Unnamed'):
        if channels is None:
            channels = ['atomic_number']
        self.filename, self.labels = filename, labels
        self.tot_batches = tot_batches
        self.directory = directory
        self.verbose = verbose
        self.batch_size = batch_size
        self.save_chunks = saved_chunks
        self.pad_len = pad_len
        self.bin = n_bin
        self.test = test_run
        self.current_file = None
        self.sub_sec = sub_sec
        self.channels = channels
        self.name = name
        if self.tot_batches is None:
            self.tot_batches = len(self.filename)
        if not self.tot_batches * self.sub_sec > 0:
            raise ValueError('You should specify total number of batches and it should be greater than 0')
        if self.test:
            print(Color.BOLD + Color.RED + '=' * 100 + Color.END, flush=True)
            txt = 'This is a test run.'
            warnings.warn(txt)
            print(txt)
            print(Color.BOLD + Color.RED + '=' * 100 + Color.END, flush=True)
        if self.verbose > 0:
            print('The generator was initialized with verbose = {}'.format(self.verbose), flush=True)

    def __len__(self):
        if self.tot_batches == 0 and self.save_chunks:
            raise ValueError("When you used saved chunks you have to specify number of total batches")
        if not self.tot_batches == 0:
            return self.tot_batches * self.sub_sec
        return int(np.ceil(len(self.filename) / float(self.batch_size)))

    def __getitem__(self, idx):
        # ######DEBUG_START
        # print('Get item: ', idx)
        # mat = np.random.rand(5, 32, 32, 32, 1)
        # return mat, mat
        # ######DEBUG-END
        data = bind = None
        try:
            time0 = datetime.now()
            if self.verbose >= 2:
                print(f'Entered generator with idx = {idx}', end='\n', flush=True)
                # print('\tMemory = {}'.format(memory_info()), end='', flush=True)
            requested_file = self.filename[int(idx / self.sub_sec)]
            if not requested_file == self.current_file:
                if self.verbose >= 1:
                    print(f'\nReading the next file from HHD. idx = {idx} Current file = {requested_file}', flush=True)
                util.data_mat = np.asarray(load_var(requested_file))
                if self.verbose >= 1:
                    print('Containing {} samples. Dividing into {} sections with ~{} samples in each'.format(
                        len(util.data_mat), self.sub_sec, int(len(util.data_mat) / self.sub_sec)))
                self.current_file = requested_file
            # np.array_split(range(len(util.data_mat)), self.sub_sec)[idx % self.sub_sec]
            data = util.data_mat[np.array_split(range(len(util.data_mat)), self.sub_sec)[idx % self.sub_sec]]
            if self.test:
                warnings.warn('This is a test')
                # data = data[:int(len(data) / 20)]
                data = data[:int(len(data) / 4)]
            # mat = np.expand_dims(np.concatenate((np.expand_dims(np.zeros((self.bin,) * 3), axis=0),) * len(data)),
            #                      axis=-1)
            mat2 = np.zeros((len(data), self.bin, self.bin, self.bin, len(self.channels)))
            # print('Mat made')
            for i in range(len(data)):
                bind = data[i]['Binds']
                channels = channel_generator(data[i]['Btypes'], self.channels)
                # mat[i, bind[:, 0], bind[:, 1], bind[:, 2], 0] = data[i]['Btypes'] / 118
                # ch1 = data[i]['Btypes'] / 118
                for c in range(channels.shape[1]):
                    mat2[i, bind[:, 0], bind[:, 1], bind[:, 2], c] = channels[:, c]
        except Exception as e:
            d = {'self': self, 'idx': idx, 'data': data, 'Bind': bind}
            save_var(locals(), 'sessions/SampleGenerator.pkl')
            print('Ali: Session saved at sessions/SampleGenerator.pkl')
            print(e)
            raise
        if self.verbose >= 1:
            clc_time = str(datetime.now() - time0).split('.')[0]
            print(f'Exit generator idx={idx}, calc. time = {clc_time}', flush=True)
        return mat2, mat2





def train_cae():
    comments = '''3 channels: A#, G, P
    model 5 
    '''

    run = RunSet(params={'pad_len': 17.5 * 4,
                         'n_bins': 32 * 4,
                         'data_set': 'all_pymatgen_5e-2/mat_set_128/',
                         'neg_x': 'anomaly_cspd/mat_set_128/',
                         'num_epochs': 5,
                         'batch_sub_sec': 70,  # To resolve memory issue go for higher values
                         'samples_fraction': .1,
                         'random_seed': 1,
                         'loss': 'binary_crossentropy',
                         'channels': ['atomic_number', 'group', 'period'],
                         # 'test': True,
                         'comments': comments},
                 )

    print(datetime.now)

    if 'random_seed' in run.params.keys():
        random_seed(run.params['random_seed'])

    train_generator = SampleGenerator(filename=run.train_x['filename'],
                                      pad_len=run.pad_len,
                                      n_bin=run.n_bins,
                                      verbose=0,
                                      # verbose=2,  # ???????????
                                      sub_sec=run.batch_sub_sec,
                                      # test_run=True
                                      channels=run.params['channels'],
                                      name='train_generator'
                                      )

    if not hasattr(run, 'input_shape'):
        input_shape = (run.n_bins, run.n_bins, run.n_bins, len(run.params['channels']))
        run.input_shape = input_shape

    # auto_encoder = model_5_cae(input_shape=run.input_shape, loss=run.params['loss'])
    auto_encoder = CAE(input_shape=(128, 128, 128, 3), pool_size=[4, 4, 2])
    run.cae_model = auto_encoder
    save_var(run, run.results_path + 'run.pkl', make_path=True)
    auto_encoder = auto_encoder.generate()
    auto_encoder.save(run.results_path + 'model_before_training.h5')
    print('Generators were created')
    print('Right before fitting', flush=True)

    # Check points
    callbacks_list = [
        ModelCheckpoint(run.results_path + 'checkpoint_model.hdf5', monitor='loss', verbose=1),
        LossHistory(run=run)
    ]


    for i in range(20):
        train_generator.__getitem__(i)

    cpu = -1
    if '--cpu' in sys.argv:
        cpu = int(sys.argv[sys.argv.index('--cpu') + 1])
    print(f'Running on {cpu} CPUs.')

    history = auto_encoder.fit_generator(
        generator=run.train_generator,
        steps_per_epoch=len(run.train_generator),
        # generator=tg,
        # steps_per_epoch=len(tg),
        epochs=run.num_epochs,
        verbose=1,
        shuffle=False,
        validation_data=run.test_generator,
        validation_steps=len(run.test_generator),
        # validation_data=tsg,
        # validation_steps=len(tsg),
        callbacks=callbacks_list,
        use_multiprocessing=True,
        workers=cpu,
        max_queue_size=15,
    )

    # auto_encoder.load_weights(run.last_run + 'weights_tmp.h5')

    print(f'Fitting {i} completed!', flush=True)

    auto_encoder.save(run.results_path + f'model_{i}.h5')
    auto_encoder.save_weights(run.results_path + f'weights_{i}.h5')

    # Extracting features
    pos_x_train = feature_extraction(generator=run.train_generator, run=run, auto_encoder=auto_encoder)
    save_var(pos_x_train, run.results_path + 'pos_train_features.pkl')

    pos_x_test = feature_extraction(generator=run.test_generator, run=run, auto_encoder=auto_encoder)
    save_var(pos_x_test, run.results_path + 'pos_test_features.pkl')

    neg_x = feature_extraction(run.params['neg_x'], run=run, auto_encoder=auto_encoder, frac=0.2)
    save_var(neg_x, run.results_path + 'neg_features.pkl')

    run.end_time = datetime.now()
    save_var(run, run.results_path + 'run.pkl')
    print('Duration: {}'.format(str(run.end_time - run.start_time).split('.')[0]))
    print('End time: {}'.format(run.end_time), flush=True)


def add_session_to_plot(ses):
    run = ses['run']
    history = ses['history']
    D = len(run.model.input.shape) - 2
    loss = run.model.loss
    plt.plot(history.epoch, history.history['loss'], label='Loss: {}'.format(loss))
    plt.plot(history.epoch, history.history['val_loss'], label='Loss: {} (Evaluation)'.format(loss))
    plt.legend()


def plot_cae():
    tf_shut_up()

    for file in list_all_files('results/run_0*/', 'autoencoder*.pkl')[-4:]:
        print('File= ', file)
        session = load_var(file)
        run_var = RunSet(session['run'])
        plt.figure(0)
        plt.title('Crystal - CAE\nPad: 17.5 & bins: 32')
        add_session_to_plot(session)
        plt.figure()
        plt.title('Crystal - CAE\n Loss: {}'.format(run_var.model.loss))
        for key in run_var.history.history:
            if key == 'loss' or key == 'val_loss':
                plt.plot(run_var.history.epoch, run_var.history.history[key], label=key, linewidth=4)
            else:
                plt.plot(run_var.history.epoch, run_var.history.history[key], label=key)
        plt.legend()
    for i in plt.get_fignums():
        plt.figure(i)
        axes = plt.gca()
        axes.set_xlim([0, 50])
        axes.set_ylim([0, .8])
        plt.ylabel('Loss')
        plt.xlabel('epoch')
        plt.savefig('results/plot_{}.png'.format(i), dpi=600)
    plt.show()


if __name__ == '__main__':

    # run = RunSet(path='results/run_006/run.pkl')
    train_cae()
    # save_features()
    # plot_cae()
    print('The End')
