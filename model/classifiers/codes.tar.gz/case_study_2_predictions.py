from utility.util_crystal import *
from predict_synthesis import predict_crystal_synthesis


def make_the_lists():
    os.system("/home/ali/anaconda3/envs/mat2vec/bin/python case_study_2.py")


def make_predictions():
    data = load_var(data_path + 'case_study/cspd_word_search_hyp.pkl')
    for word in data:
        for db in ['hyp', 'cod']:
            for atoms in data[word][db]:
                pred = predict_crystal_synthesis(atoms['atom'],
                                                 # auto_encoder='results/CAE/run_045/',
                                                 # classifiers='results/Classification/run_045/'
                                                 )
                for c in pred.columns:
                    atoms[c] = pred[c]
    save_var(data, data_path + 'case_study/cspd_word_search_hyp_pred.pkl')


if __name__ == '__main__':
    # make_the_lists()
    # make_predictions()
    threshold = 0.5
    data = load_var(data_path + 'case_study/cspd_word_search_hyp_pred.pkl')
    clf_names = [c for c in data['cathode']['hyp'][3].columns if 'Classifier' in c]
    for word in data:
        for c in clf_names:
            data[word].update({c: []})
            for db in [
                # 'hyp',
                'cod'
            ]:
                for atoms in data[word][db]:
                    if c in atoms.columns:
                        data[word][c].append(np.count_nonzero(atoms[c] > threshold))
                    else:
                        data[word][c].append(0)
        del data[word]['hyp']
        del data[word]['cod']
        pd.DataFrame(data[word]).to_excel(data_path + f'case_study/{word}_{db}.xlsx')
    print('The End')
