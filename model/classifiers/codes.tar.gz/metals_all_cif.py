import bokeh.sampledata.periodic_table as pt
import numpy as np
from ase.io import read
from os import listdir, sep

# a = pt.elements.metal=='nonmetal'
# b = pt.elements.metal=='nobel gas'
# c = pt.elements.metal=='alkali metal'
# d = pt.elements.metal=='alkaline erth metal'
e = pt.elements.metal == 'transition metal'
f = pt.elements.metal == 'metal'
# g = pt.elements.metal=='halogen'
# h = pt.elements.metal=='metalloid'
i = pt.elements.metal == 'actinoid'
j = pt.elements.metal == 'lanthanoid'
metals = e | f | i | j
table = pt.elements.values[metals, :]
metals_elements = table[:, 1]

output = open('metalics.txt', 'w')
output.close()

directory = '/home/ali/Downloads/cod/cif' + sep
N_total = 0
N_metal = 0
N_failed = 0
for i in range(1, 10):
    for j in listdir(directory + str(i)):
        for k in listdir(directory + str(i) + sep + j):
            training_filenames = [x for x in listdir(directory + str(i) + sep + j + sep + k) if 'cif' in x]
            print('Working directory: ', directory + str(i) + sep + j + sep + k + sep)
            output = open('metalics.txt', 'a')
            for filename in training_filenames:
                try:
                    atoms = read(directory + str(i) + sep + j + sep + k + sep + filename)
                except:
                    # print('Error in reading file: ', filename)
                    N_failed += 1
                    continue
                N_total += 1
                elements = np.unique(np.array(atoms.get_chemical_symbols()))
                if set(elements).issubset(set(metals_elements)):
                    N_metal += 1
                    # print('The file ', filename, 'is a METALIC structure')
                    output.write(str(i) + sep + j + sep + k + sep + filename + '\n')
                # else:
                #     print('The file ', filename, 'is a NON-METALIC structure')
            output.close()

output.close()
print('N metals = ', N_metal)
print('N total = ', N_total)
print('End')
