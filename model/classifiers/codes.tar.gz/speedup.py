from utility.util_general import *
import seaborn as sns

sns.set_style()

files = list_all_files('results/speedup/nn_training/', pattern='cpu_*')

