import pandas
# import re
import numpy as np

fp = open('/home/ali/Downloads/cod/mysql/spacegroups.txt', 'r')
data = []
for i in fp:
    st = i.split('\t')
    # st = re.split('(.)+\t',i)
    data.append(st)
header = ['id', 'ITCn', 'Hall', 'Schoenflies', 'HM', 'HMu', 'class', 'Nau']
data = np.asarray(data)
sg = pandas.DataFrame(data[0:,1:],index=data[0:,0],columns=header[1:])
sg.to_csv('sg.csv')
sg.to_pickle('sg.pkl')
fp.close()