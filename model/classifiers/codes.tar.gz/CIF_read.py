from ase.io import read
from utility import *


def read_cif(filename, len_limit=50., n_bins=64, atoms_unit=None): ### INSTEAD of this use atom2mat from cod_tools
    n_bins = np.uint8(n_bins)
    # Reading CIF
    if atoms_unit is None:
        if not exists(filename):
            raise FileNotFoundError('File were not found')
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            try:
                atoms_unit = read(filename)
            except:
                raise Exception('ASE can\'t  read the file. ')
    else:
        filename = atoms_unit.filename
    # Calc. atom geometry
    a_unit = atoms_unit.get_positions()
    a_unit -= np.amin(a_unit, axis=0)  # bringing the minimum to the origin
    # if np.trim_zeros(np.sort(atoms_unit.repeat((2, 2, 2)).get_all_distances().ravel()))[0] > 10:
    #     raise Exception("Too large crystal size")
    # a_unit_max = np.amax(a_unit, axis=0)
    # a_unit_min = np.amin(a_unit, axis=0)
    # a_size1 = a_unit_max - a_unit_min

    # a_double = atoms_unit.repeat((2, 2, 2)).get_positions()
    # a_size2 = np.amax(a_double, axis=0) - np.amin(a_double, axis=0)

    # Calc. moving speeds
    # abc = atoms_unit.get_cell_lengths_and_angles()[:3]
    # angles = atoms_unit.get_cell_lengths_and_angles()[3:] * np.pi / 180
    # a1 = np.array((abc[0], 0, 0))
    # a2 = np.array((abc[1] * np.cos(angles[2]), abc[1] * np.sin(angles[2]), 0))
    # cx = abc[2] * np.cos(angles[1])
    # cy = abc[2] * (np.cos(angles[0]) - np.cos(angles[1]) * np.cos(angles[2])) / np.sin(angles[2])
    # cz = (abc[2] ** 2 - cx ** 2 - cy ** 2) ** 0.5
    # a3 = np.array((cx, cy, cz))
    # speed = np.amax(np.vstack((a1, a2, a3)), axis=0) - np.sort(np.abs(np.vstack((a1, a2, a3))), axis=0)[1, :]
    len_limit = np.ones((3)).astype('uint8') * len_limit
    cell = atoms_unit.get_cell()
    speed = np.asarray([cell[i][i] - max(np.abs(np.delete(cell[:, i], i))) for i in range(3)])
    if (speed == 0).any():
        raise ValueError('Growth in a direction is zero')
    reps = np.ceil(len_limit / speed + 1).astype('uint8')

    atoms_reps = atoms_unit.repeat(reps.astype('int'))
    mat_reps = atoms_reps.get_positions()
    mat_reps = mat_reps - np.amin(mat_reps, axis=0) - (
            (np.amax(mat_reps, axis=0) - np.amin(mat_reps, axis=0)) / 2 - len_limit / 2)

    Btypes = atoms_reps.get_atomic_numbers()
    if np.any(Btypes < 1):
        raise Exception('ASE can\'t  read the file. ')  # Because there is a negative element
    # B = np.zeros((n_bins, n_bins, n_bins)).astype('uint8')
    Bind = np.round(mat_reps / len_limit * n_bins).astype('uint8')
    atoms2 = atoms_reps.copy()
    atoms2.set_positions(Bind)
    if np.min(np.max(mat_reps, axis=0), axis=0) < np.amin(len_limit, axis=0):
        raise ValueError("Replication error. Not big enough")
    if np.max(np.min(mat_reps, axis=0), axis=0) > 0:
        raise ValueError("Replication error. Axises not properly set to zero")

    # PADDING
    upper = (Bind >= np.array((n_bins, n_bins, n_bins))).any(axis=1)
    lower = (Bind < np.array((0, 0, 0))).any(axis=1)
    eliminations = np.logical_or(upper, lower)
    keep = np.logical_not(eliminations)
    padding_lost = Btypes[eliminations]
    padding_ind_eli = np.arange(len(eliminations))[eliminations]
    # B[Bind[keep][:, 0], Bind[keep][:, 1], Bind[keep][:, 2]] = Btypes[keep]
    Bind_eli = Bind[eliminations]
    Btypes_eli = Btypes[eliminations]
    Bind = Bind[keep]
    Btypes = Btypes[keep]

    unique, counts = np.unique(atoms_reps.get_atomic_numbers(), return_counts=True)
    # unique, counts2 = np.unique(np.concatenate((B[B != 0], np.array(padding_lost)), axis=0), return_counts=True)
    unique, counts2 = np.unique(np.concatenate((Btypes, np.array(padding_lost)), axis=0), return_counts=True)
    if not np.array_equal(counts, counts2):
        # raise ValueError("There is a bug in calculations of the matrix, it couldn't "
        #                  "get all the the atoms")
        # warnings.warn("There is a bug in calculations of the matrix, it couldn't "
        #               "get all the the atoms")
        raise ValueError("Error in padding.")

    del atoms2[[atom for atom in padding_ind_eli]]
    Aout = atoms2.get_positions().astype('uint8')
    unique, counts = np.unique(atoms2.get_atomic_numbers(), return_counts=True)
    unique, counts2 = np.unique(Btypes, return_counts=True)
    if not np.array_equal(counts, counts2):
        raise ValueError("Error in padding.")
        # warnings.warn("Error in padding.")
    return {'reps': reps, 'min': np.amin(Aout, axis=0), 'max': np.amax(Aout, axis=0), 'Binds': Bind,
            'Btypes': Btypes, 'n_bins': n_bins, 'pad_len': len_limit, 'filename': filename,
            'symbols': atoms_unit.symbols}


def cif2chunk(total_sections=100, selected_sections=-1, query_filter=None, data_set='cod/cif/',
              output_path='cod/cif_chunks/'):
    if selected_sections == -1:
        selected_sections = range(total_sections)
    print('Converting all cif files chunks.', flush=True)
    print('Selected sections: ', selected_sections, flush=True)
    err_reading = []
    if query_filter is not None:
        all_files = run_query(query_filter)
        for i in range(len(all_files)):
            d = str(all_files[i][0])
            all_files[i] = data_path + 'cod/cif/' + d[0] + '/' + d[1:3] + '/' + d[3:5] + '/' + d + '.cif'
    else:
        # if exists('all_files.cif.pkl'):
        #     with open('all_files.cif.pkl', 'rb') as fp:
        #         all_files = pickle.load(fp)
        # else:
        root_dir = data_path + data_set
        all_files = list_all_files(root_dir, pattern='**/*.cif')
        # all_files = [f for f in glob(root_dir + "**/*.cif", recursive=True)]
        # with open('all_files.cif.pkl', 'wb') as pickle_file:
        #     pickle.dump(all_files, pickle_file)
    random.shuffle(all_files)
    all_files = np.array_split(all_files, total_sections)
    for i in range(len(selected_sections)):
        files = all_files[selected_sections[i]]
        data = []
        for j in range(len(files)):
            filename = files[j]
            print('Progress: {}/{} \t Chunk#: {}/{} \tFile: {}/{}: {}'.format(i + 1, len(selected_sections),
                                                                              selected_sections[i], len(all_files), j,
                                                                              len(files), filename))
            if not exists(filename):
                raise FileNotFoundError('File were not found')
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                try:
                    atoms_unit = read(filename)
                except:
                    err_reading.append(filename)
                    print('Error in reading cif')
                    continue
            atoms_unit.filename = filename
            data.append(atoms_unit)
        print('Chunk complete.')
        directory = data_path + output_path
        # if total_sections != 100:
        #     directory = data_path + 'cod/cif_chunks_{}/'.format(total_sections)
        makedirs(directory, exist_ok=True)
        with open(directory + '{:04d}.pkl'.format(selected_sections[i]), 'wb') as pickle_file:
            pickle.dump(data, pickle_file)
            pickle_file.close()
            del pickle_file, data
    print('Preparing the results to exit')
    with open(directory + 'errors.pkl', 'wb') as pickle_file:
        pickle.dump(err_reading, pickle_file)
        pickle_file.close()
    summary(directory)


def cif_chunk2mat(total_sections=100, selected_sections=-1, pad_len=70., n_bins=128, break_into_subsection=1,
                  target_data='cod/cif_chunks/', output_dataset='cod/mat_chunks/'):
    if selected_sections == -1:
        selected_sections = range(total_sections)
    print('Time: ', datetime.now())
    print('Converting all cif chunks to matrices. (test)', flush=True)
    print('Total sections = {} \t Sub-sections = {}'.format(total_sections, break_into_subsection))
    print('Selected sections: ', selected_sections, flush=True)
    print('Pad length = {} \t#bins = {}'.format(pad_len, n_bins))
    err_padding = err_reading = err_elements = 0

    output_dir = data_path + output_dataset + 'len{}_bin{}_tot.sec{}.sub{}/'.format(pad_len, n_bins,
                                                                                    total_sections,
                                                                                    break_into_subsection)

    all_files = list_all_files(data_path + target_data, pattern="[0-9]*.pkl")
    df = pandas.DataFrame(columns=['filename', 'n_samples'])
    for i in range(len(selected_sections)):
        print('Opening file #', i, ' :', all_files[selected_sections[i]])
        with open(all_files[selected_sections[i]], 'rb') as pickle_file:
            loaded_files = np.array_split(pickle.load(pickle_file), break_into_subsection)
            pickle_file.close()
            del pickle_file
        for sub in range(len(loaded_files)):
            files = loaded_files[sub]
            data = []
            for j in range(len(files)):
                if j in np.floor(np.linspace(0, len(files) - 1, 10)):
                    print('Progress: {}/{} \t Chunk#: ({}) {}/{} \tFile: {}/{}\tMemory: {}'.format(i + 1,
                                                                                                   len(
                                                                                                       selected_sections),
                                                                                                   sub,
                                                                                                   selected_sections[i],
                                                                                                   len(all_files), j,
                                                                                                   len(files),
                                                                                                   memory_info()),
                          flush=True)
                try:
                    d = read_cif(filename='', len_limit=pad_len, n_bins=n_bins, atoms_unit=files[j])
                except Exception as e:
                    print('\t', '\u25b2', end=' ')
                    if str(e) == 'ASE can\'t  read the file. ':
                        print(e, 'Skipping the file.')
                        err_reading += 1
                        continue
                    elif str(e) == 'Includes unacceptable elements':
                        print(e, 'Skipping the file.')
                        err_elements += 1
                        continue
                    elif str(e) == "Error in padding.":
                        print(e, 'Skipping the file.')
                        err_padding += 1
                        continue
                    elif str(e) == "Too large crystal size":
                        print(e, 'Skipping the file.')
                        err_elements += 1
                        continue
                    else:
                        print(e, flush=True)
                        warnings.warn(str(e))
                        print('The case was skipped.', flush=True)
                        continue
                data.append(d)
            makedirs(output_dir, exist_ok=True)
            print('Saving sub-section', output_dir + '{:03d}.{:03d}.pkl'.format(selected_sections[i], sub))
            with open(output_dir + '{:03d}.{:03d}.pkl'.format(selected_sections[i], sub), 'wb') as f:
                pickle.dump(data, f)
                f.close()
                df = df.append({'filename': output_dir, 'n_samples': len(data)}, ignore_index=True)
                del f, data, files
            gc.collect()  # garbage collector
        del loaded_files
        gc.collect()
    df['CUM_SUM'] = df['n_samples'].cumsum()
    with pandas.option_context('display.max_rows', None, 'display.max_columns',
                               None):  # more options can be specified also
        print(df)
    with open(output_dir + 'summary.pkl', 'wb') as f1:
        pickle.dump(df, f1)
    with open(output_dir + 'summary.txt', 'w') as f1:
        print(df.to_string(), file=f1)


def anomaly2mat():
    chunk = 0
    atoms_in_each_chunks = 1000
    pad_len = 17.5
    n_bins = 32
    for file in list_all_files('../Hypotheticals/AtomicStructureGenerator-master/results/anomaly', pattern='*.pkl'):
        print('loading the file: ', file)
        structures_list = load_var(file)
        data = []
        for df in range(len(structures_list)):
            if df in np.floor(np.linspace(0, len(structures_list) - 1, 10)):
                print('Progress %{:.2f}'.format((df + 1) / len(structures_list) * 100))
            for atoms in structures_list[df]['atom']:
                try:
                    d = read_cif(filename='', len_limit=pad_len, n_bins=n_bins, atoms_unit=atoms)
                except Exception as e:
                    print('\t', '\u25b2', end=' ')
                    if str(e) == 'ASE can\'t  read the file. ':
                        print(e, 'Skipping the file.')
                        continue
                    elif str(e) == 'Includes unacceptable elements':
                        print(e, 'Skipping the file.')
                        continue
                    elif str(e) == "Error in padding.":
                        print(e, 'Skipping the file.')
                        continue
                    elif str(e) == "Too large crystal size":
                        print(e, 'Skipping the file.')
                        continue
                    else:
                        print(e, flush=True)
                        warnings.warn(str(e))
                        print('The case was skipped.', flush=True)
                        continue
                data.append(d)

    print('End anomaly to mat')


if __name__ == "__main__":
    gc.enable()
    random.seed = 0
    time_start = datetime.now()

    # read_cif('/home/ali/Downloads/2209646.cif')

    # if len(argv) > 2:
    #     log_filename = 'log.CIF.{}-{}.txt'.format(argv[1], argv[2])
    #     print('Redirecting to a log file: ', log_filename, flush=True)
    #     log = open(log_filename, "w")
    #     sys.stdout = log
    # selected_sections = range(0, 3)
    # if len(argv) > 1:
    #     selected_sections = [int(argv[1])]
    #     if len(argv) > 2:
    #         selected_sections = range(int(argv[1]), int(argv[2]))
    # section_num = sections_tot = 1

    # cif2chunk(total_sections=4,
    #           data_set='anomaly_mp',
    #           output_path='anomaly_mp/chunks/'
    #           # query_filter='select file from cod_data where a<10 and b<10 and c<10'
    #           )

    cif_chunk2mat(pad_len=17.5,
                  n_bins=64,
                  break_into_subsection=1,
                  target_data='cod/cif_chunks_abc_10',
                  # output_dataset=''
                  )

    # pad_len = 70
    # n_bins = 128
    # if len(argv) > 1:
    #     sections_tot = int(argv[1])
    #     section_num = int(argv[2])
    # print('Args: total sections={} \tsection #={} '.format(sections_tot, section_num), flush=True)
    # print('Pad length = {}\t # bins = {}'.format(pad_len, n_bins), flush=True)
    # convert_all_cif_to_mat(len_limit=pad_len, n_bins=n_bins)

    # Converting
    time_end = datetime.now()
    print('End\t', time_end - time_start)
