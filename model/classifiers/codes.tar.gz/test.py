from utility.util_general import *
from bokeh.sampledata.periodic_table import elements as plt
import dask.array as da
import numpy as np


# def f(B):
#     ali = 'ali'
#     B += 1
#     print(B)
#     globals().update(locals())
#     return locals()
#
#
# # x = da.random.random((50,128,128,128,3), chunks=(5, 128, 128, 128, 3))
# A = np.asarray([[1, 2], [3, 4]])
# print(A)
# out = f(A)
# locals().update(out)
#
# print(A)
#

# bat = load_var(data_path + 'cod/battery/battery.pkl')
# print('End')


# a = np.array([1, 2])
# b = [3, 4]
#
# d = {'a': a, 'b': b}
# d['a'] = d['a'] + 1
# d['a'] += 1
# d['b'] += [5]
# d['b'] = d['b'] + [5]

# from pymatgen.analysis.surface_analysis import SlabEntry
# import numpy as np
# from ase import Atoms
# from ase.io.trajectory import Trajectory
# from pymatgen.core.surface import SlabGenerator, generate_all_slabs, Structure, Lattice
#
# lattice = Lattice.cubic(3.61)
#
# Cu = Structure(lattice, ["Cu", "Cu", "Cu", "Cu"],
#                [[0, 0, 0], [0, 0.5, 0],
#                 [0.5, 0, 0], [0, 0, 0.5]
#                 ])
#
# Cu100 = SlabEntry(Cu, 0.996, miller_index=(1, 0, 0))
#
# Cu100.surface_energy(ucell_entry=Cu100)

# clf_old = load_var('/home/ali/Data/cod/results/Classification/run_043_all_data/classifiers.pkl')

# def fun1(**kwargs):
#     print(kwargs)
# fun1(ali='3', b=5)

# import matplotlib.pyplot as plt
# plt.plot([1 , 2, 3], [1, 2, 3], 'P')
# plt.show()

files = list_all_files(path='results/pca_comet/', pattern='**/metrics.pkl')
print(files)
dfs = [load_var(f) for f in files]
df = pd.concat(dfs)
save_var(df, 'results/pca_comet/results.pkl')
df.to_csv('results/pca_comet/results.csv')
print(df)

print('The End')
