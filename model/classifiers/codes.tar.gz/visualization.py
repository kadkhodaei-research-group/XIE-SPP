from utility.util_crystal import *
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from samplegenerator import SampleGenerator
from cod_tools import *
# This import registers the 3D projection, but is otherwise unused.
from mpl_toolkits.mplot3d import Axes3D  # noqa: F401 unused import

def cube():
    # prepare some coordinates
    x, y, z = np.indices((8, 8, 8))

    # draw cuboids in the top left and bottom right corners, and a link between them
    cube1 = (x < 3) & (y < 3) & (z < 3)
    cube2 = (x >= 5) & (y >= 5) & (z >= 5)
    link = abs(x - y) + abs(y - z) + abs(z - x) <= 2

    # combine the objects into a single boolean array
    voxels = cube1 | cube2 | link

    # set the colors of each object
    colors = np.empty(voxels.shape, dtype=object)
    colors[link] = 'red'
    colors[cube1] = 'blue'
    colors[cube2] = 'green'

    # and plot everything
    fig = plt.figure()
    ax = fig.gca(projection='3d')
    ax.voxels(voxels, facecolors=colors, edgecolor='k')

    plt.show()
    comments = ''
    run = RunSet(params={'pad_len': 17.5 * 4,
                         'n_bins': 32 * 4,
                         'data_set': 'all_pymatgen_5e-2/mat_set_128/',
                         'neg_x': 'anomaly_cspd/mat_set_128/',
                         'num_epochs': 5,
                         'batch_sub_sec': 400,  # To resolve memory issue go for higher values
                         'samples_fraction': .3,
                         'random_seed': 1,
                         'loss': 'binary_crossentropy',
                         'channels': ['atomic_number', 'group', 'period'],
                         # 'test': True,
                         'comments': comments},
                 log=False)
    tot_samples_df = summary(run.chunks_path)
    train_generator = SampleGenerator(filename=tot_samples_df['filename'],
                                      pad_len=run.pad_len,
                                      n_bin=run.n_bins,
                                      verbose=0,
                                      # verbose=2,  # ???????????
                                      sub_sec=run.batch_sub_sec,
                                      # test_run=True
                                      channels=run.params['channels'],
                                      name='train_generator'
                                      )
    A = train_generator.__getitem__(1)

    voxels = A[0][0][:,:,:][0]
    # voxels =
    fig = plt.figure()
    ax = fig.gca(projection='3d')
    ax.voxels(voxels)
    plt.show()


def cube_2():
    target_data = 'cod/data_sets/all/cif_chunks/'
    iterator = 1
    n_bins = 32 * iterator
    pad_len = 17.5 * iterator
    all_files = list_all_files(data_path + target_data, pattern="[0-9]*.pkl")
    N = 1520767
    filename = expanduser(f'~/Downloads/{N}.cif')
    atoms = cif_parser(filename)
    # view_atom_vmd(atoms)
    atoms_box = atom2mat(filename='', len_limit=pad_len, n_bins=n_bins, atoms_unit=atoms, return_atom=True)
    write(f'~/Downloads/{N}_box.cif', atoms_box)
    write(f'~/Downloads/{N}_box.xyz', atoms_box)

    print('End function')



if __name__ == '__main__':
    cube_2()
    print('End')

