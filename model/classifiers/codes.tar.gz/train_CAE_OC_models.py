from keras import backend as K
from cnn_classifier_3D import *
from util import *
# from keras.callbacks import ModelCheckpoint
from feature_extraction import feature_extraction
from sklearn import svm
from sklearn.ensemble import IsolationForest
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, classification_report, precision_recall_fscore_support, roc_auc_score

tf_shut_up()
comments = '''


'''
run_1 = RunSet(params={'pad_len': 17.5,
                     'n_bins': 32,
                     'sec': 20,
                     'file_sub': 0,
                     'file_suffix': '_abc10',
                     'num_epochs': None,
                     'batch_sub_sec': 50,
                     'data_path': data_path,
                     'samples_fraction': .4,
                     'random_seed': 1,
                     'loss': 'mse',
                       'model_path': 'results/CAE/3_channels/run_001/',
                       'channels': ['atomic_number', 'group', 'period'],
                       'pos_x': data_path + 'cod/mat_chunks/len17.5_bin32_tot.sec20_abc10/',
                       'neg_x': data_path + 'anomaly_mp_abc10/len17.5_bin32_tot.sec4.sub1/',
                       'comments': comments},
               log=False)

# run_cae = load_var(run.params['model_path']+'run.pkl')['run']

print(run_1)
start_time = datetime.now()


def calc_acc(clf_1):
    y_pred_train = clf_1.predict(trainX_pos)
    y_pred_test = clf_1.predict(testX_pos)
    y_pred_test_anomaly = clf_1.predict(testX_anomaly_tot)
    acc_train = accuracy_score(np.zeros((len(y_pred_train))) + 1, y_pred_train)
    print('train accuracy = {:.2f}%'.format(acc_train * 100))
    acc_test = accuracy_score(np.zeros((len(y_pred_test))) + 1, y_pred_test)
    print('test accuracy = {:.2f}%'.format(acc_test * 100))
    acc_test_anomaly = accuracy_score(np.zeros((len(y_pred_test_anomaly))) - 1, y_pred_test_anomaly)
    print('test anomaly accuracy = {:.2f}%'.format(acc_test_anomaly * 100))

    return acc_train * 100, acc_test * 100, acc_test_anomaly * 100


def one_class_train():
    print('Fitting the model', flush=True)
    oc_svm = svm.OneClassSVM(nu=0.5, kernel='rbf', gamma='auto', verbose=True)
    isolation_forest = IsolationForest(behaviour='new', max_samples=100,
                                       contamination='auto',
                                       verbose=1)
    # gmm = GMM(n_components=18)
    for c in [oc_svm, isolation_forest]:
        print('-' * 50)
        print(c)
        c.fit(trainX_pos)
        calc_acc(c)
    return {'oc_svm': oc_svm, 'isolation_forest': isolation_forest}


def binary_train():
    print('Fitting the model', flush=True)
    svm_clf = svm.SVC(gamma='auto')
    for c in [svm_clf]:
        print('-' * 50)
        print(c)
        c.fit(X_train, y_train)
        predY = c.predict(X_test)
        print('accuracy = ', accuracy_score(y_test, predY))
        print('auc = ', roc_auc_score(y_test, predY))
        print(classification_report(y_test, predY))


if __name__ == '__main__':
    print('Extracting features')
    # input_shape = (run.n_bins, run.n_bins, run.n_bins, len(run.params['channels']))
    # auto_encoder = model_5_cae(input_shape=input_shape, loss=run.params['loss'])
    # auto_encoder.load_weights(run.params['model_path'] + 'weights.h5')
    # print('model layers: ', len(auto_encoder.layers))
    # pos_x = feature_extraction(run.params['pos_x'], run, encoder=auto_encoder)
    # save_var(pos_x, run.params['pos_x'] + 'features_2c.pkl')
    #
    # neg_x = feature_extraction(run.params['neg_x'], run, encoder=auto_encoder)
    # save_var(neg_x, run.params['neg_x'] + 'features_2c.pkl')

    pos_x = load_var(run_1.params['pos_x'] + 'features.pkl')
    neg_x = load_var(run_1.params['neg_x'] + 'features.pkl')
    print('Tot. pos samples = {}\nTot. neg samples = {}'.format(len(pos_x), len(neg_x)))
    pos_split = 5
    trainX_pos, testX_pos = train_test_split(pos_x[:len(pos_x) // 5], test_size=0.33, shuffle=True)
    testX_anomaly_tot = neg_x

    print('Apply standard scalar to features')
    ss = StandardScaler()
    ss.fit(trainX_pos)
    trainX_pos = ss.transform(trainX_pos)
    testX_pos = ss.transform(testX_pos)
    testX_anomaly_tot = ss.transform(testX_anomaly_tot)

    print('Taking PCA to reduce feature space dimensionality')
    pca = PCA(n_components=512, whiten=True)
    pca = pca.fit(trainX_pos)
    trainX_pos = pca.transform(trainX_pos)
    testX_pos = pca.transform(testX_pos)
    testX_anomaly_tot = pca.transform(testX_anomaly_tot)

    print('Preparing test data')
    testX = np.concatenate([testX_pos, testX_anomaly_tot])
    testY = np.concatenate([[1] * len(testX_pos), [-1] * len(testX_anomaly_tot)])

    X_tot = np.concatenate((pos_x[:len(pos_x) // pos_split], neg_x), axis=0)
    Y_tot = np.concatenate(([1] * (len(pos_x) // pos_split), [-1] * len(neg_x)), axis=0)
    X_train, X_test, y_train, y_test = train_test_split(X_tot, Y_tot, test_size=0.33, random_state=42)

    print('Training classifiers')
    binary_train()
    # clf = one_class_train()
    # save_var(clf, 'tmp/clf.pkl')
    #
    # print('-' * 20)
    # print('Metrics reports')
    # clf = load_var('tmp/clf.pkl')
    # for i in clf:
    #     print(i)
    #     predY = clf[i].predict(testX)
    #     print('accuracy = ', accuracy_score(testY, predY))
    #     print('auc = ', roc_auc_score(testY, predY))
    #     print(classification_report(testY, predY))

    session = {'num_epochs': run_1.num_epochs,
               'data_path': data_path,
               'run': run_1,
               # 'acc_summary': df_summary,
               }
    save_var(session, run_1.results_path + 'oc.pkl')
    end_time = datetime.now()
    print('Duration: {}'.format(end_time - start_time), flush=True)
