from utility.utility_general import *
import imp
from utility import util_plot
from utility import util_plot as Plots
imp.reload(util_plot)
imp.reload(Plots)

# pd.set_option('display.width', 1000)
# pd.set_option('display.max_columns', 500)
# pd.set_option('display.max_rows',None)
# pd.set_option('display.max_colwidth', 500)

from datetime import datetime
from joblib import Parallel, delayed
from tqdm import tqdm, tqdm_notebook
from ase.formula import Formula

import matplotlib
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import matplotlib.font_manager

from matplotlib.ticker import (MultipleLocator, AutoMinorLocator)

try:
    matplotlib.font_manager._rebuild()
except AttributeError:
    pass

save_plot = True
n_top_comp = 15

data = pd.read_csv(f'{local_data_path}/data_bases/cspd/summary.csv',
                   index_col=0)
natural_formula = [
    'TiO2', 'ZnO', 'CO2', 'SiO2', 'Al2O3', 'CSi', 'GaAs', 'GaN', 'ZrO2',
    'SnO2', 'MgO', 'CdS', 'CeO2', 'H2O', 'Fe3O4'
]
data = data.head(len(natural_formula))
data['natural formula'] = natural_formula
data['natural formula'] = [Formula(i).format('latex') for i in data['natural formula']]

# plt.style.use('seaborn-paper')
# sns.set_style("whitegrid")
# sns.set_context('paper')
f, axs, fs = util_plot.plot_format((88, 70), ncols=2)

################# Plot b)
ax = axs[0]
sns.barplot(
    x="literature",
    y="natural formula",
    data=data,
    label="Study intensity",
    color='slateblue',
    # palette="GnBu_d",
    # palette="pastel",
    ax=ax,
)

ax.set_ylabel('')
ax.set_xlabel('Absolute repetition')
# ax.xaxis.set_ticks([0, 1, 2, 3, 4, 5])

# ax.yaxis.grid(False)
ax.yaxis.grid(True)
# ax.grid()
lines, labels = ax.get_legend_handles_labels()
# ax.legend(lines + lines2, labels + labels2, loc='lower right')


################# Plot c)
ax = axs[1]

sns.barplot(data=data, x='anomaly selected', y='natural formula', color='darkred')
ax.set_ylabel('')
ax.set_xlabel('# of selected polymorphs', fontsize=fs)
ax.xaxis.set_ticks([0, 20, 40])

ax.yaxis.grid(True)
ax.xaxis.grid(True)

# ax.grid('on')
# ax.grid()

lines2, labels2 = ax.get_legend_handles_labels()
# ax.get_yaxis().set_visible(False)
ax.legend(loc='lower right')

ax.xaxis.set_major_locator(MultipleLocator(20))
# ax.xaxis.set_major_formatter('{x:.0f}')


###############
Plots.annotate_subplots_with_abc(axs, x=0, y=1.05, start_from=1)
if save_plot:
    Plots.plot_save('literature_b_c_', save_to_papers=True)
plt.show()
pass
